#include "ktp.h"
void* receiver_thread(void* arg){return 0;}
