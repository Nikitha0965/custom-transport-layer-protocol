#include "ktp.h"
void* sender_thread(void* arg){return 0;}
