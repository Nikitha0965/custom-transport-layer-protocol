# Custom Transport Layer Protocol (KTP)
Reliable protocol over UDP with retransmissions and ordering.
