#ifndef KTP_H
#define KTP_H
int ktp_socket();
int ktp_bind(int sockfd, int port);
int ktp_send(int sockfd, const void *buf, int len);
int ktp_recv(int sockfd, void *buf, int len);
int ktp_close(int sockfd);
#endif
